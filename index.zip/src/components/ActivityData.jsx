import { MapPin } from "lucide-react";

export const ActivityInfo = ({ activity }) => (
  <div className="px-4 py-2 shadow-sm">
    <h2 className="font-bold text-green-600 mb-3">Activity Info:</h2>
    <div className="flex items-start gap-4">
      <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center">
        <MapPin className="w-4 h-4 text-green-500" />
      </div>

      <div className="flex-1 space-y-2">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-lg font-semibold">{activity.activityType}</p>
            {activity.description && (
              <p className="text-sm text-gray-600">{activity.description}</p>
            )}
          </div>
          {activity.occasionType && (
            <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
              {activity.occasionType}
            </span>
          )}
        </div>

        {activity.specialRequirements && (
          <div className="text-sm text-gray-500">
            <p className="font-semibold">Special Requirements:</p>
            <p>{activity.specialRequirements}</p>
          </div>
        )}
      </div>
    </div>
  </div>
);
