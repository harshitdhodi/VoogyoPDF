import React from "react";
import { MapPin, Plane, Bed } from "lucide-react";
import { SegmentInfo } from "../ItenarySegment";
import { TransportInfo } from "../TransportData";
import { HotelInfo } from "../HotelInfo";
import { ActivityInfo } from "../ActivityData";

const ItineraryWithTransport = ({ itineraries = [], transports = [], hotels = [], activities = [] }) => {
  console.log("Activities:", activities);

  // Map transports by day
  const transportsByDay = itineraries.reduce((acc, itinerary, index) => {
    acc[itinerary.dayNumber] = (transports || []).filter((_, i) => i === index);
    return acc;
  }, {});

  // Map hotels by day
  const hotelsByDay = itineraries.reduce((acc, itinerary) => {
    acc[itinerary.dayNumber] = (hotels || []).filter((hotel) => {
      const hotelStartDate = new Date(hotel.startDate);
      const itineraryStartDate = new Date(itinerary.startDate);
      return hotelStartDate.toDateString() === itineraryStartDate.toDateString();
    });

    return acc;
  }, {});

  // Map activities by day
  const activitiesByDay = itineraries.reduce((acc, itinerary) => {
    const dayKey = ` ${itinerary.dayNumber}`; // Match the format
  
    const matchedActivities = (activities || []).filter(activity =>
      activity.dayNumbers.includes(dayKey) // Ensure correct comparison
    );
  
    acc[itinerary.dayNumber] = matchedActivities.length ? matchedActivities : [];
    return acc;
  }, {});
  
  return (
    <div className="space-y-8">
      {itineraries.map((itinerary) => (
        <div key={itinerary.id} className="border-t pt-6">
          <h2 className="text-2xl bg-gray-200 px-5 py-2 font-bold">
            {`Day ${itinerary.dayNumber}`}
          </h2>

          {/* Transports for the day */}
          {transportsByDay[itinerary.dayNumber]?.map((transport) => (
            <TransportInfo key={transport.id} transport={transport} />
          ))}

          {/* Hotels for the day */}
          {hotelsByDay[itinerary.dayNumber]?.map((hotel) => (
            <HotelInfo key={hotel.id} hotel={hotel} />
          ))}

          {/* Activities for the day */}
          {activitiesByDay[itinerary.dayNumber]?.map((activity) => (
            <ActivityInfo key={activity.id} activity={activity} />
          ))}

          {/* Segments for the day */}
          {itinerary.segments.map((segment) => (
            <SegmentInfo key={segment.id} segment={segment} />
          ))}
        </div>
      ))}
    </div>
  );
};

export default ItineraryWithTransport;
