// import React from 'react';
// import { ItinerarySegment } from './ItenarySegment';

// export const ItineraryDay = ({ day }) => {
//     console.log(day)
//   return (
//     <div className="page-break p-6 day-section  border-t">
//       <div className="bg-blue-600 text-white p-8">
//         <h2 className="text-3xl font-bold">{day.dayNumber}</h2>
//       </div>
      
//       {day.segments?.map((segment, segmentIndex) => (
//         <ItinerarySegment key={segmentIndex} segment={segment} />
//       ))}
//     </div>
//   );
// };